/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Conejo extends Mascotas{
    
    private String tipoComida;

    public Conejo(String tipoComida, String nombre, String codigo, float peso, int edad, int diasAlojamiento, boolean supervision) {
        super(nombre, codigo, peso, edad, diasAlojamiento, supervision);
        this.tipoComida = tipoComida;
    }

    public Conejo(String tipoComida) {
        this.tipoComida = tipoComida;
    }

    public String getTipoComida() {
        return tipoComida;
    }

    public void setTipoComida(String tipoComida) {
        this.tipoComida = tipoComida;
    }

    @Override
    public String toString() {
        return "Conejo{" +super.toString()+ "tipoComida=" + tipoComida + '}';
    }

    @Override
    public void mostrarDatos() {
        System.out.println(toString()); 
    }
    
    @Override
    public void mostrarNacionalidad() {
        System.out.println("MASCOTA FILIPINO");
        System.out.println("EL PRECIO ES "+PRECIO);
    }
    
    
    
}
