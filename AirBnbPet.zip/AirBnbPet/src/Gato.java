/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Gato extends Mascotas {
    
    private String pedigri;

    public Gato(String pedigri, String nombre, String codigo, float peso, int edad, int diasAlojamiento, boolean supervision) {
        super(nombre, codigo, peso, edad, diasAlojamiento, supervision);
        this.pedigri = pedigri;
    }

    public Gato(String pedigri) {
        this.pedigri = pedigri;
    }

    public String getPedigri() {
        return pedigri;
    }

    public void setPedigri(String pedigri) {
        this.pedigri = pedigri;
    }

    @Override
    public String toString() {
        return "Gato{" +super.toString()+ "pedigri=" + pedigri + '}';
    }

    @Override
    public void mostrarDatos() {
        System.out.println(toString()); 
    }
    
    @Override
    public void mostrarNacionalidad() {
        System.out.println("MASCOTA PERUANO");
    }
    
    
    
}
