/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public interface Interface {
    
    int PRECIO = 100_000;
    
    void mostrarNacionalidad();
    
}
