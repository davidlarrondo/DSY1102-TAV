/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public abstract class Mascotas implements Interface{
    
    protected String nombre,codigo;
    protected float peso;
    protected int edad,diasAlojamiento;
    protected boolean supervision;

    public Mascotas(String nombre, String codigo, float peso, int edad, int diasAlojamiento, boolean supervision) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.peso = peso;
        this.edad = edad;
        this.diasAlojamiento = diasAlojamiento;
        this.supervision = supervision;
    }

    public Mascotas() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getDiasAlojamiento() {
        return diasAlojamiento;
    }

    public void setDiasAlojamiento(int diasAlojamiento) {
        this.diasAlojamiento = diasAlojamiento;
    }

    public boolean isSupervision() {
        return supervision;
    }

    public void setSupervision(boolean supervision) {
        this.supervision = supervision;
    }

    @Override
    public String toString() {
        return "Mascotas{" + "nombre=" + nombre + ", codigo=" + codigo + ", peso=" + peso + ", edad=" + edad + ", diasAlojamiento=" + diasAlojamiento + ", supervision=" + supervision + '}';
    }
    
    public abstract void mostrarDatos();


    
    
    
    
    
    
    
    
    
    
}
