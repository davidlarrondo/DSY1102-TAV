/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Perro extends Mascotas{
    
    private boolean realizaEjercicio;

    public Perro(boolean realizaEjercicio, String nombre, String codigo, float peso, int edad, int diasAlojamiento, boolean supervision) {
        super(nombre, codigo, peso, edad, diasAlojamiento, supervision);
        this.realizaEjercicio = realizaEjercicio;
    }

    public Perro(boolean realizaEjercicio) {
        this.realizaEjercicio = realizaEjercicio;
    }

    public boolean isRealizaEjercicio() {
        return realizaEjercicio;
    }

    public void setRealizaEjercicio(boolean realizaEjercicio) {
        this.realizaEjercicio = realizaEjercicio;
    }

    @Override
    public String toString() {
        return "Perro{" +super.toString()+ "realizaEjercicio=" + realizaEjercicio + '}';
    }

    @Override
    public void mostrarDatos() {
        System.out.println(toString()); 
    }

    @Override
    public void mostrarNacionalidad() {
        System.out.println("MASCOTA CHILENA");
    }


    
    
   
    
    
    
    
}
