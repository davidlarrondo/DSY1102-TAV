
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Registro {
    
    private ArrayList<Mascotas> listaMascotas;

    public Registro() {
        listaMascotas = new ArrayList<>();
    }
    
    public boolean validarCodigo(Mascotas mascota){
        for (Mascotas i : listaMascotas) {
            if (i.getCodigo().equalsIgnoreCase(mascota.getCodigo())) {
                return true;
            }
        }return false;  
    }
    
    public boolean agregar(Mascotas mascota){
        if (validarCodigo(mascota)==true) {
            System.out.println("MASCOTA YA REGISTRADA");
            return false;
        } else {
            System.out.println("MASCOTA REGISTRADA EXITOSAMENTE");
          return listaMascotas.add(mascota);  
        }
        
    }
    
    public void listar(){
        System.out.println("LISTA DE MASCOTAS");
        System.out.println("------------------");
        for (Mascotas i : listaMascotas) {
            System.out.println(i);
            i.mostrarNacionalidad();
        }
        System.out.println("------------------");
    }
    
    public void cantidadMascotas(){
        System.out.println("CANTIDAD DE MASCOTAS "+listaMascotas.size());
    }
    
    
    
}
