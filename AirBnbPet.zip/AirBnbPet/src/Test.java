/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Test {
    
    public static void main(String[] args) {
        
        Perro perro1 = new Perro(true, "HOMERO", "123", 80f, 12, 10, true);
        Perro perro2 = new Perro(true, "MORITA", "123", 10f, 5, 1, false);
        
        Gato gato1 = new Gato("Angora", "Con botas", "345", 5.0f, 5, 0, true);
        Gato gato2 = new Gato("Persa", "Bola de nieve", "555", 6.0f, 4, 1, false);
        
        Conejo conejo1 = new Conejo("ZANAHORIA", "ALGODÓN","777", 4.0f, 3, 1, true);
        Conejo conejo2 = new Conejo("CONEJÍN", "CHOROLAX","888", 7.0f, 6, 2, false);
        
        Registro registro = new Registro();
        registro.agregar(perro1);
        registro.agregar(perro2);
        registro.agregar(gato1);
        registro.agregar(gato2);
        registro.agregar(conejo1);
        registro.agregar(conejo2);
        registro.listar();
        registro.cantidadMascotas();
        
        
    }
    
    
}
