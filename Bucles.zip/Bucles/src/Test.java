
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Test {
    public static void main(String[] args) {
        //while
//        int i=10;
//        while (i>=0) {
//            System.out.println(i);
//            i--;
//        }
        //for
        // start, stop, step
//        for (int i = 10; i>=0; i--) {
//            System.out.println(i);
//            
//        }
        
        //do while
//        int i=10;
//        do {    
//            System.out.println(i);
//            i--;
//            
//            
//        } while (i>=0);

        Scanner teclado = new Scanner(System.in);
        int opcion;
        
        do {       
            System.out.println("-----MENÚ OTAKU-----");
            System.out.println("(1) OTAKU ROLL");
            System.out.println("(2) OTAKOS");
            System.out.println("(3) PIKACHU ROLL");
            System.out.println("(4) ENTRAR A LA COMIC CON");
            System.out.println("(5) DUCHA");
            System.out.println("(0) SALIR");
            System.out.println("SELECCIONE OPCIÓN ");
            opcion =teclado.nextInt();
            
            switch (opcion) {
                case 1 -> System.out.println("COMPRASTE UN OTAKU ROLL");
                case 2 -> System.out.println("COMPRASTE UN OTAKOS");
                case 3 -> System.out.println("COMPRASTE UN PIKACHU ROLL");
                case 4 -> System.out.println("COMPRASTE UNA ENTRADA A LA COMIC CON");
                case 5 -> System.out.println("COMPRASTE UN TICKET PARA DUCHARTE");
                case 0 -> System.out.println("ADIÓS!");
                default -> System.out.println("OPCIÓN INVÁLIDA");
            }
            
                    
            
        } while (opcion!=0);
    }
}
