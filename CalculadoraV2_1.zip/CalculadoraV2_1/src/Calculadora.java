/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Calculadora {
    
    private int numero1, numero2;

    public Calculadora(int numero1, int numero2) {
        this.numero1 = numero1;
        this.numero2 = numero2;
    }

    public Calculadora() {
    }
    
    public int operar(int numero1, int numero2, String operador){
        int resultado=0;
        switch (operador) {
            case "+" -> resultado=numero1+numero2;
            case "-" -> resultado=numero1-numero2;
            case "*" -> resultado=numero1*numero2;
            case "/" -> resultado=numero1/numero2;
            default -> {
            }
        }
        return resultado;
        
    }
    
    
          
    
}
