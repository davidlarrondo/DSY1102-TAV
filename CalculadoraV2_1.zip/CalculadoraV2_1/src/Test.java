
import java.util.Scanner;



public class Test {
    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        Calculadora objeto1 = new Calculadora(5, 3);
        System.out.println("INGRESE UN VALOR ");
        int valor1 = teclado.nextInt();
        System.out.println("INGRESE OTRO VALOR ");
        int valor2 = teclado.nextInt();
        System.out.println("INGRESE OPERACIÓN A REALIZAR (+-*/)");
        String operador = teclado.next();
        System.out.println(objeto1.operar(valor1,valor2,operador));
        

        
        
        
    }
    
}
