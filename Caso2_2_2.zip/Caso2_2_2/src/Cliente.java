
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Cliente {
    
    private String idCliente,nombre;
    private ArrayList<Pedido> pedidosRealizados;

    public Cliente(String idCliente, String nombre) {
        this.idCliente = idCliente;
        this.nombre = nombre;
        pedidosRealizados = new ArrayList<Pedido>();
    }

    public Cliente() {
        
    }

    public String getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Cliente{" + "idCliente=" + idCliente + ", nombre=" + nombre + '}';
    }
    
    public boolean agregarPedido(Pedido pedido){
        return pedidosRealizados.add(pedido);
    }
    
    public void listarPedido(){
        System.out.println("LISTA DE PEDIDOS");
        System.out.println("-----------------");
        for (Pedido i : pedidosRealizados) {
            System.out.println(i);
        }
        System.out.println("-----------------");
    }
    
    

    
    
    
    
}
