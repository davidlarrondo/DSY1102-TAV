
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Pedido {
    
    private ArrayList<Producto> listaProductos;
    private double total;

    public Pedido() {
        listaProductos = new ArrayList<Producto>();
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    @Override
    public String toString() {
        return "Pedido{" + this.listaProductos+"total=" + calcularTotal() + '}';
    }
    
    public double calcularTotal(){
        
        for (Producto i : listaProductos) {
            this.total= this.total+i.precio;
        }
        return total;
    }
    
    public boolean agregarProducto(Producto producto){//método que agregar productos a la colección
        return listaProductos.add(producto);
    }
    
    public void listar(){//método que lista la colección
        for (Producto i : listaProductos) {
            System.out.println(i);
        }
    }
    
    
    
    
    
}
