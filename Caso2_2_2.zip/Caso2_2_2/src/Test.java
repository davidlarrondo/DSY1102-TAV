/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Test {
    
    public static void main(String[] args) {
        
        Electronico electronico1 = new Electronico("SONY", 12,"123", "SMART TV", 800_000);
        Electronico electronico2 = new Electronico("SAMSUNG", 24,"333", "NOTEBOOK", 1_800_000);
    
        Ropa ropa1 = new Ropa("XXL", "ROSADO","456", "POLERA", 20_000);
        Ropa ropa2 = new Ropa("XL", "AZUL","556", "JEANS", 40_000);
        
        Pedido pedido1 = new Pedido();
        pedido1.agregarProducto(ropa2);
        pedido1.agregarProducto(ropa1);
        pedido1.agregarProducto(electronico1);
        pedido1.agregarProducto(electronico2);
        pedido1.listar();

        Cliente cliente1 = new Cliente("111", "HERNY SAAVEDRA");
        
        System.out.println(cliente1.toString());
        cliente1.agregarPedido(pedido1);
        cliente1.listarPedido();
        
        
    }
    
}
