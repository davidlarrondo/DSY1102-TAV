/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Calculadora {
    
    //calculadora que opera 2 valores mediante +-*/
    //crear atributos
    //crear métodos customer correspondientes
    //crear constructores
    //mostrar por pantalla el resultado
    
    private int numero1,numero2;

    public Calculadora(int numero1, int numero2) {
        this.numero1 = numero1;
        this.numero2 = numero2;
    }

    public Calculadora() {
    }
    
    public void sumar(){
        int resultado= numero1+numero2;
        System.out.println("la suma es "+ resultado);
    }
    public void restar(){
        int resultado= numero1-numero2;
        System.out.println("la resta es "+ resultado);
    }
    public void multiplicar(){
        int resultado= numero1*numero2;
        System.out.println("la multiplicación es "+ resultado);
    }
    public void dividir(){
        float resultado= (float)numero1/numero2;
        System.out.println("la división es "+ resultado);
    }

//    public int getNumero1() {
//        return numero1;
//    }
//
//    public int getNumero2() {
//        return numero2;
//    }
    
    
    
   
    
    
    
}
