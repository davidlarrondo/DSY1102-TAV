/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Test {
    
    public static void main(String[] args) {
        Calculadora objeto1 = new Calculadora(4, 3);
        objeto1.sumar();
        objeto1.restar();
        objeto1.dividir();
        objeto1.multiplicar(); 
//        System.out.println(objeto1.getNumero1());
                
    }
    
}
