
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Empresa {
    
    private ArrayList<Empleado> listaEmpleados;

    public Empresa() {
        listaEmpleados = new ArrayList<Empleado>();
    }
    
    //AGREGAR 
    public boolean agregar(Empleado emple){
        return listaEmpleados.add(emple);
    }
    
    //BUSCAR
    public boolean buscarEmpleado(String rut){
        for (Empleado i : listaEmpleados) {
            if (i.getRut().equalsIgnoreCase(rut)) {
                return true;
            }
        }
        return false;
    }
    
    //LISTAR
    public void listarEmpleados(){
        for (Empleado i : listaEmpleados) {
            System.out.println(i); 
        }
    }
    
    //ELMINAR 
    public boolean eliminarEmpleado(String rut){
        for (Empleado i : listaEmpleados) {
            if (i.getRut().equalsIgnoreCase(rut)) {
                listaEmpleados.remove(i);
                return true;
            }
        }
        return false;
    }
    
    
    //CRUD
    //CREATE 
    //READ
    //UPDATE
    //DELETE 
    
    
    
    
    
}
