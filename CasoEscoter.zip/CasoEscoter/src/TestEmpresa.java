/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class TestEmpresa {
    
    public static void main(String[] args) {
        
        
        Puesto puesto1 = new Puesto(1, "YOUTUBER");
        Puesto puesto2 = new Puesto(2, "INFLUENCER");
        Puesto puesto3 = new Puesto(3, "GERENTE");
        
        Empleado empleado1 = new Empleado("111", "ALAN BRITO", 'M', 10, 44, puesto1);
        Empleado empleado2 = new Empleado("333", "ELSA PATO", 'F', 12, 54, puesto2);
        Empleado empleado3 = new Empleado("222", "ARMANDO CASAS", 'M', 13, 64, puesto3);
        
        Empresa empresa1 = new Empresa();
        
        //agregar empleado
        if (empresa1.buscarEmpleado("111")==false) {
            empresa1.agregar(empleado1);   
            System.out.println("EMPLEADO AGREGAGO EXITOSAMENTE");
        } else {
            System.out.println("EL EMPLEADO YA EXISTE");
        }
        
        //listar empleados
        empresa1.listarEmpleados();
        
        //eliminar
        if (empresa1.eliminarEmpleado("111")) {
            System.out.println("EMPLEADO ELIMINADO EXITOSAMENTE");
        } else {
            System.out.println("EMPLEADO NO ENCONTRADO");
        }
        
        //listar empleados
        empresa1.listarEmpleados();
       
    }
    
}
