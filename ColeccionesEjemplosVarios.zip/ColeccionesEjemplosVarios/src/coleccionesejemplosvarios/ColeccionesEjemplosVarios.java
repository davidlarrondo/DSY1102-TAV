/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package coleccionesejemplosvarios;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author USRVI-LC12
 */
public class ColeccionesEjemplosVarios {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int opcion,posicion;
        String nombre;
        Scanner teclado = new Scanner(System.in);
        List<String> listaNombres = new ArrayList<>();

        do { 
            System.out.println("MENÚ PRINCIPAL");
            System.out.println("(1)GUARDAR DATOS");
            System.out.println("(2)MSOTRAR DATOS");
            System.out.println("(3)ELIMINAR DATOS POR CONTENIDO");
            System.out.println("(4)ELIMINAR DATOS POR POSICIÓN");
            System.out.println("(5)BUSCAR");
            System.out.println("(6)MOSTRAR CANTIDAD DE ELEMENTOS EN LA COLECCIÓN");
            System.out.println("(7)BORRAR TODO");
            System.out.println("(0)SALIR");
            System.out.println("SELECCIONE OPCIÓN");
            opcion=teclado.nextInt();
            
            switch (opcion) {
                case 1 -> {
                    System.out.println("INGRESE NOMBRE ");
                    nombre=teclado.next();
                    nombre=nombre.toUpperCase();
                    listaNombres.add(nombre);
                }
                case 2 -> {
                    System.out.println("LISTA DE NOMBRES");
                    System.out.println("------------------");
                    //usamos el bucle FOR versión inteligente
                    for (String i : listaNombres) {
                        System.out.println(listaNombres.indexOf(i)+":"+i); //i representa cada elemento de la lista
                    }
                    System.out.println("------------------");
                }
                case 3 -> {
                    System.out.println("INGRESE NOMBRE A ELIMINAR");
                    nombre=teclado.next();
                    listaNombres.remove(nombre); //REMOVE ELIMINA SEGÚN EL CONTENIDO O LA POSICIÓN
                }
                case 4 -> {
                    System.out.println("INGRESE POSICIÓN DEL ELEMENTO A ELIMINAR");
                    posicion=teclado.nextInt();
                    listaNombres.remove(posicion); //REMOVE ELIMINA SEGÚN EL CONTENIDO O LA POSICIÓN
                }
                case 5 -> {
                    System.out.println("INGRESE NOMBRE A BUSCAR");
                    nombre=teclado.next();
                    System.out.println(listaNombres.contains(nombre)); //CONTAINS DEVUELVE TRUE SI ENCUENTRA EL ELEMENTO
                }
                case 6 -> {
                    System.out.println("CANTIDAD DE ELEMENTOS EN LA LISTA "+listaNombres.size());
                }
                case 7 -> {
                    listaNombres.clear();
                }
                case 0 -> {
                    System.out.println("ADIÓS!");
                }
                default -> System.out.println("OPCIÓN INVÁLIDA");
            }
            
        } while (opcion!=0);
        
        
        
        
    }
    
}
