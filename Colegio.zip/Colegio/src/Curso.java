/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Curso {
    
    private int nivel;
    private String jornada;
    private Alumno alumno1,alumno2;

    public Curso(int nivel, String jornada, Alumno alumno1, Alumno alumno2) {
        this.nivel = nivel;
        this.jornada = jornada;
        this.alumno1 = alumno1;
        this.alumno2 = alumno2;
    }

    public Curso() {
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public String getJornada() {
        return jornada;
    }

    public void setJornada(String jornada) {
        this.jornada = jornada;
    }

    public Alumno getAlumno1() {
        return alumno1;
    }

    public void setAlumno1(Alumno alumno1) {
        this.alumno1 = alumno1;
    }

    public Alumno getAlumno2() {
        return alumno2;
    }

    public void setAlumno2(Alumno alumno2) {
        this.alumno2 = alumno2;
    }

    @Override
    public String toString() {
        return "Curso{" + "nivel=" + nivel + "\njornada=" + jornada + "\nalumno1=" + alumno1 + "\nalumno2=" + alumno2 + '}';
    }

    

    

    
    
    
    
}
