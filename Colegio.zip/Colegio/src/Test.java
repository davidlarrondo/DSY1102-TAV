/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Test {
    
    public static void main(String[] args) {
        
        Nota nota1  = new Nota(3.5f, 4.5f, 5.6f);
        Alumno alumno1 = new Alumno("111", "ALAN", "BALLET", nota1);
        Nota nota2  = new Nota(4.5f, 4.5f, 6.6f);
        Alumno alumno2 = new Alumno("333", "ELSA", ",MECÁNICA", nota2);
        Curso curso1 = new Curso(1, "DIURNA", alumno1,alumno2);
        System.out.println(curso1.toString());
        
         
        
    }
    
}
