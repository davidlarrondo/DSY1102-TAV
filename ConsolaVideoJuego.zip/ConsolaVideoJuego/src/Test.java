/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Test {
    public static void main(String[] args) {
        // creamos el objeto
       Consola objeto1 = new Consola("NINTENDO", "SWITCH", 380000);
       
        //imprimimos todos los atributos
       System.out.println(objeto1.toString());
       
       //imprimimos solo la marca
       System.out.println("LA MARCA ES "+objeto1.getMarca());
       
       //modificamos la marca
       objeto1.setMarca("SONY");
       
       //imprimimos solo la marca
       System.out.println("LA MARCA ES "+objeto1.getMarca());
               
       //llamar a los métodos customer        
       objeto1.encender();
       objeto1.apagar();
       
        
        
    }
    
    
}
