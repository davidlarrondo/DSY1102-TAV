/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public abstract class Animal {
    
    protected String nombre;
    protected int peso;
    protected boolean especieProtegida;

    public Animal(String nombre, int peso, boolean especieProtegida) {
        this.nombre = nombre;
        this.peso = peso;
        this.especieProtegida = especieProtegida;
    }

    public Animal() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public boolean isEspecieProtegida() {
        return especieProtegida;
    }

    public void setEspecieProtegida(boolean especieProtegida) {
        this.especieProtegida = especieProtegida;
    }

    @Override
    public String toString() {
        return "Animal{" + "nombre=" + nombre + ", peso=" + peso + ", especieProtegida=" + especieProtegida + '}';
    }
    
    public abstract void mover();
    
            
    
}
