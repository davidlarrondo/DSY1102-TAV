/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Capibara extends Animal implements PorPagar{
    
    private String apodo;

    public Capibara(String apodo, String nombre, int peso, boolean especieProtegida) {
        super(nombre, peso, especieProtegida);
        this.apodo = apodo;
    }

    public Capibara(String apodo) {
        this.apodo = apodo;
    }
 

    @Override
    public void mover() {
        System.out.println("EL CAPIBARA CAMINA CON JORGE");
    }

    @Override
    public String toString() {
        return "Capibara{" +super.toString()+ "apodo=" + apodo + '}';
    }

    @Override
    public void calcularPago() {
        System.out.println("total a pagar $100.000"); 
        System.out.println("el iva a pagar es de "+IVA);
               
    }
     
    
    
    
}
