/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Ornitorrinco extends Animal{
    
    private int cantidadHuevos;

    public Ornitorrinco(int cantidadHuevos, String nombre, int peso, boolean especieProtegida) {
        super(nombre, peso, especieProtegida);
        this.cantidadHuevos = cantidadHuevos;
    }

    public Ornitorrinco(int cantidadHuevos) {
        this.cantidadHuevos = cantidadHuevos;
    }

    @Override
    public void mover() {
        System.out.println("CAMINA EN 4 PATAS");
    }

    @Override
    public String toString() {
        return "Ornitorrinco{" +super.toString()+ "cantidadHuevos=" + cantidadHuevos + '}';
    }
    
    
    
    
    
    
    
}
