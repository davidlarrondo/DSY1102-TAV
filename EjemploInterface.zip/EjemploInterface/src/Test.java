/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Test {
    
    public static void main(String[] args) {
        Capibara capibara1 = new Capibara("CASTOR", "JORGE VALENCIA", 10, true);
        System.out.println(capibara1.toString());
        capibara1.mover();
        capibara1.calcularPago();
        Ornitorrinco ornitorrinco1 =  new Ornitorrinco(5, "perry", 100, true);
        System.out.println(ornitorrinco1.toString());
        ornitorrinco1.mover();
        
    }
    
}
