
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class CasoDos {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int lista1=0, lista2=0, cantidad=0,valor;
        
        System.out.println("LISTA 1");
        while (cantidad<3) {
            System.out.println("INGRESE UN VALOR ");
            valor = teclado.nextInt();
            lista1=lista1+valor;
            cantidad++;
        }
        
        cantidad=0;
        System.out.println("LISTA 2");
        while (cantidad<3) {
            System.out.println("INGRESE UN VALOR ");
            valor = teclado.nextInt();
            lista2=lista2+valor;
            cantidad++;
        }
        if (lista1>lista2) {
            System.out.println("LISTA 1 ES MAYOR");
            
        } else if(lista2>lista1){
            System.out.println("LISTA 2 ES MAYOR");  
        }else{
            System.out.println("SON IGUALES");
        }
        
        System.out.println("TOTAL LISTA 1 "+lista1);
        System.out.println("TOTAL LISTA 2 "+lista2);
    }
}
