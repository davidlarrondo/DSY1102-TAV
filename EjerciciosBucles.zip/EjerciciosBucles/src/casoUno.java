/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class casoUno {
    
    
    public static void main(String[] args) {
        
        int valor=11;
        int iterador=0;
        while (iterador<25) {
            System.out.println(valor);
            valor+=11;
            iterador++;
                    
                    
        }
    }
    
}
