/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Gato extends Animal{
    
    private boolean otaku;

    public Gato(boolean otaku, String nombre, int edad, float peso) {
        super(nombre, edad, peso);
        this.otaku = otaku;
    }

    public Gato(boolean otaku) {
        this.otaku = otaku;
    }

    public Gato() {
    }

    public boolean isOtaku() {
        return otaku;
    }

    public void setOtaku(boolean otaku) {
        this.otaku = otaku;
    }

    @Override
    public String toString() {
        return super.toString()+"Gato{" + "otaku=" + otaku + '}';
    }
    
    
}
