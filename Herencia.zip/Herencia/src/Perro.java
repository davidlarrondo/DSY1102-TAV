/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Perro extends Animal{
    
    private boolean adiestrado;

    public Perro(boolean adiestrado, String nombre, int edad, float peso) {
        super(nombre, edad, peso);
        this.adiestrado = adiestrado;
    }

    public Perro(boolean adiestrado) {
        this.adiestrado = adiestrado;
    }

    public Perro() {
    }

    public boolean isAdiestrado() {
        return adiestrado;
    }

    public void setAdiestrado(boolean adiestrado) {
        this.adiestrado = adiestrado;
    }

    @Override
    public String toString() {
        return super.toString()+"Perro{" + "adiestrado=" + adiestrado + '}';
    }
    
    
    
    
    
    
    
}
