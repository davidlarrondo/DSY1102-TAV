/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Test {
    
    public static void main(String[] args) {
        
        Perro perro1 = new Perro(true, "BEETHOVEN", 10, 70);
        Perro perro2 = new Perro(false, "HOMERO", 11, 75);
        
        Gato gato1 = new Gato(true, "GARFIELD", 10, 10.5f);
        Gato gato2 = new Gato(true, "CON BOTAS", 15, 12.5f);
        
        System.out.println(perro1.toString());
        System.out.println(perro2.toString());
        System.out.println(gato1.toString());
        System.out.println(gato2.toString());
        
    }
    
}
