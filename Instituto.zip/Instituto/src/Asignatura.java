/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Asignatura {
    

    private String codigo,nombre;
    private Alumno alumno;
    private Docente docente;
    private float nota1,nota2,nota3;

    public Asignatura(String codigo, String nombre, Alumno alumno, Docente docente, float nota1, float nota2, float nota3) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.alumno = alumno;
        this.docente = docente;
        this.nota1 = nota1;
        this.nota2 = nota2;
        this.nota3 = nota3;
    }

    public Asignatura() {
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Alumno getAlumno() {
        return alumno;
    }

    public void setAlumno(Alumno alumno) {
        this.alumno = alumno;
    }

    public Docente getDocente() {
        return docente;
    }

    public void setDocente(Docente docente) {
        this.docente = docente;
    }

    public float getNota1() {
        return nota1;
    }

    public void setNota1(float nota1) {
        this.nota1 = nota1;
    }

    public float getNota2() {
        return nota2;
    }

    public void setNota2(float nota2) {
        this.nota2 = nota2;
    }

    public float getNota3() {
        return nota3;
    }

    public void setNota3(float nota3) {
        this.nota3 = nota3;
    }

    @Override
    public String toString() {
        return "Asignatura{" + "\ncodigo=" + codigo + "\nnombre=" + nombre + "\nalumno=" + alumno + "\ndocente=" + docente + "\nnota1=" + nota1 + "\nnota2=" + nota2 + "\nnota3=" + nota3 ;
    }
    
    public float promedio(){
        float promedio=0;
        promedio=(this.nota1+this.nota2+this.nota3)/3;
        return promedio;
    }
    
    public void estado(){
        if (promedio()>3.9f) {
            System.out.println("APRUEBA");
        } else {
            System.out.println("REPRUEBA");
        }
    }
    
    
    
    
    
}
