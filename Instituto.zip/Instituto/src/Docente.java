
import java.time.LocalDate;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 * REGLAS DE NEGOCIO AÑADIDAS
 * SEDE DEBE SER VIÑA DEL MAR O ANTONIO VARAS
 * EDAD DEL ALUMNO DEBE SER MAYOR IGUAL A 17
 * EL RUT DEL DOCENTE DEBE TENER UN LARGO DE 11 O 12 DIGITOS
 * 
 * MÉTODOS CUSTOMER
 * MÉTODO QUE CALCULA EL PROMEDIO
 * MÉTODO QUE DETERMINAR SI APRUEBA O REPRUEBA 
 * 
 * AGREGAR MENÚ Y SCANNER
 * 
 * 
 */
public class Docente {
    
    private String rut,nombre,sede;
    private int numeroDocente;
    private LocalDate fechaIngreso;

    public Docente(String rut, String nombre, String sede, int numeroDocente, LocalDate fechaIngreso) {
        setRut(rut);
        this.nombre = nombre;
        setSede(sede);
        this.numeroDocente = numeroDocente;
        this.fechaIngreso = fechaIngreso;
    }

    public Docente() {
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        if (rut.length()==11 || rut.length()==12) {
            this.rut = rut;
        } else {
            System.out.println("EL RUT DEBE TENER UN LARGO DE 11 O O 12 DÍGITOS");
        }
        
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSede() {
        return sede;
    }

    public void setSede(String sede) {
        if (sede.equalsIgnoreCase("VIÑA DEL MAR") || sede.equalsIgnoreCase("ANTONIO VARAS")) {
            this.sede = sede;
        } else {
            System.out.println("LA SEDE DEBE SER VIÑA DE MAR O ANTONIO VARAS");
        }
    }

    public int getNumeroDocente() {
        return numeroDocente;
    }

    public void setNumeroDocente(int numeroDocente) {
        this.numeroDocente = numeroDocente;
    }

    public LocalDate getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(LocalDate fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    @Override
    public String toString() {
        return "Docente{" + "rut=" + rut + ", nombre=" + nombre + ", sede=" + sede + ", numeroDocente=" + numeroDocente + ", fechaIngreso=" + fechaIngreso + '}';
    }
    
    
    
    
}
