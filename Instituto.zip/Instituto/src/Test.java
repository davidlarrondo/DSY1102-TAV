
import java.time.LocalDate;
import java.time.Month;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC12
 */
public class Test {
    
    public static void main(String[] args) {
        
        int opcion;
        Scanner teclado = new Scanner(System.in);
        
        LocalDate fechaNacimiento1 = LocalDate.of(2005, 12, 20);
        Alumno alumno1 = new Alumno("111","PEPE", 19, fechaNacimiento1);

        LocalDate fechaIngreso = LocalDate.of(2000, 03, 10);
        Docente docente1 = new Docente("1.111.111-1", "HERNÁN SAAVEDRA", "VIÑA DEL MAR", 129,fechaIngreso );
        
        Asignatura asignatura1 = new Asignatura("444", "BASE DE DATOS", alumno1, docente1, 4.5f, 5.5f, 6.6f);
        
        do {   
            System.out.println("MENÚ PRINCIPAL");
            System.out.println("(1)MOSTRAR DATOS");
            System.out.println("(2)MOSTRAR PROMEDIO");
            System.out.println("(3)MOSTRAR ESTADO");
            System.out.println("(0)SALIR");
            System.out.println("SELECCIONE OPCIÓN");
            opcion=teclado.nextInt();
            
            switch (opcion) {
                case 1 -> {
                    System.out.println("MOSTRAR DATOS");
                    System.out.println(asignatura1.toString());
                }
                case 2 -> {
                    System.out.println("MOSTRAR PROMEDIO");
                    System.out.println("PROMEDIO "+asignatura1.promedio());
                }
                case 3 -> {
                    System.out.println("MOSTRAR ESTADO");
                    asignatura1.estado();
                }
                case 0 -> System.out.println("ADIÓS");
                default -> System.out.println("SELECCIONE OPCIÓN VÁLIDA");
            }
        } while (opcion!=0);
        
        
        

        
        
        
                
        
        
    }
    
    
}
