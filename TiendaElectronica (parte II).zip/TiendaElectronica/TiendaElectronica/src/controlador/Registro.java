/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import bd.Conexion;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import javax.swing.JOptionPane;


public class Registro extends bd.Conexion {
    
    private String sql;
    
    public void listar(JTable tabla, DefaultTableModel modelo){
        sql = "SELECT * FROM producto";
        String[] datos = new String[5];
        Connection connect = Conexion.getConectar();
        
        try {
            Statement st = connect.createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while (rs.next()) { 
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
                modelo.addRow(datos);
            }
            tabla.setModel(modelo);
            
        } catch (Exception e) {
            System.out.println("ERROR AL INTENTAR LISTAR "+e);
                    
        }finally{
            try {
                connect.close();
            } catch (Exception e) {
                System.out.println("ERROR AL INTENTAR CERRAR LA BD "+e);
            } 
        }
    }
    
    public boolean registrar(String nombre, int idCategoria, double precio, int cantidadInventario){
        PreparedStatement ps = null;
        Connection connect = getConectar();
        String query = "INSERT INTO producto (nombre, idCategoria, precio, cantidadInventario) VALUES(?,?,?,?)";
        try {
            ps = connect.prepareStatement(query);
            ps.setString(1, nombre);
            ps.setInt(2, idCategoria);
            ps.setDouble(3, precio);
            ps.setInt(4, cantidadInventario);
            ps.execute();
            return true;
        } catch (Exception e) {
            System.out.println("ERROR A INTENTAR REGISTRAR PRODUCTO "+e);
            return false;
        } finally {
            try {
                connect.close();
            } catch (Exception e) {
                System.out.println("ERROR AL INTENTAR CERRAR LA BD "+e);
            } 
        }
    }
    
    public void buscar(String idProducto, JTable tabla, DefaultTableModel modelo){
        String sql = "SELECT * FROM producto WHERE idProducto = ?";
        String [] datos = new String[5];
        
        try {
            Connection connect = getConectar();
            PreparedStatement ps = connect.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(idProducto));
            
            ResultSet rs = ps.executeQuery();
            modelo.setRowCount(0);
            
            if (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
                modelo.addRow(datos);     
            }
            tabla.setModel(modelo);
            
        } catch (Exception e) {
            System.out.println("ERROR AL BUSCAR EL PRODUCTO "+e);
        }
    }
    
    
            
            
    
}
