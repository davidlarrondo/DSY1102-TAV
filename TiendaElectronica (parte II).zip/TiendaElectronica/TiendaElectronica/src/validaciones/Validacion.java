/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package validaciones;

/**
 *
 * @author USRVI-LC12
 */
public class Validacion {
    
    public static boolean camposVacio(String campo){
        return campo==null || campo.trim().isEmpty();  
    }
    
    public static boolean sinSeleccion(int seleccionable){
        return seleccionable==-1;
    }
    
}
